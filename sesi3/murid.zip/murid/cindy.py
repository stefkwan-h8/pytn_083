nama = "Cindy"
umur = 52
hobi = ["masak", "coding"]

def menyapa():
  print("salam kenal, saya bu Cindy")

