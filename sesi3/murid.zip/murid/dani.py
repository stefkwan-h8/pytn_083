nama = "Dani"
umur = 47
hobi = ["sepeda", "boxing"]

def menyapa():
  print("yo salken, aku Dani!")

